﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    static class Constants
    {
        public static string HANDLING_STRESS = "Handling Stress";

        public static string TIME_MANAGEMENT = "Time Management";

        public static string SUPERVISION_SKILLS = "Supervision Skills";

        public static string NEGOTIATION = "Negotiation";

        public static string HOW_TO_INTERVIEW = "How to Interview";

        public static string AUSTIN = "Austin";

        public static string CHICAGO = "Chicago";

        public static string DALLAS = "Dallas";

        public static string ORLANDO = "Orlando";

        public static string PHOENIX = "Phoenix";

        public static string RALEIGH = "Raleigh";

        public static string WORKSHOP_SELECTION = "Please select avaliable workshop";

        public static string LOCATION_SELECTION = "Please select avaliable location";
    }
}
