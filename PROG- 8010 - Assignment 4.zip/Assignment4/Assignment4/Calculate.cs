﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment4
{
    class Calculate : INotifyPropertyChanged
    {
        const int HANDLING_STRESS_DAYS = 3;
        const int TIME_MANAGEMENT_DAYS = 3;
        const int SUPERVISION_DAYS = 3;
        const int NEGOTIATION_DAYS = 5;
        const int INTERVIEW_DAYS = 1;
        const double HANDLING_STRESS_FEE = 1000.00;
        const double TIME_MANAGEMENT_FEE = 800.00;
        const double SUPERVISION_FEE = 1500.00;
        const double NEGOTIATION_FEE = 1300.00;
        const double INTERVIEW_FEE = 500.00;
        const double AUSTIN_LODGE = 150.00;
        const double CHICAGO_LODGE = 225.00;
        const double DALLAS_LODGE = 175.00;
        const double ORLANDO_LODGE = 300.00;
        const double PHOENIX_LODGE = 175.00;
        const double RALEIGH_LODGE = 150.00;

        int days;
        double fee;
        double lodging;

        public List<string> WorkList
        {
            get { return _WorkList; }
            set { _WorkList = value; Notify("WorkList"); }
        }
        private List<string> _WorkList;

        public string WorkSelection
        {
            get { return _WorkSelection; }
            set
            {
                _WorkSelection = value;
                doCalc();
                Notify("WorkSelection");
            }
        }
        private string _WorkSelection;

        public List<string> LocationList
        {
            get { return _LocationList; }
            set { _LocationList = value; Notify("LocationList"); }
        }
        private List<string> _LocationList;

        public string LocationSelection
        {
            get { return _LocationSelection; }
            set
            {
                _LocationSelection = value;
                doCalc();
                Notify("LocationSelection");
            }
        }
        private string _LocationSelection;

        public string CostConversion
        {
            get { return _CostConversion; }
            set { _CostConversion = value; Notify("CostConversion"); }
        }
        private string _CostConversion;

        private void doCalc()
        {
            if (_WorkSelection != null)
            {
                if (_WorkSelection.Equals(Constants.HANDLING_STRESS))
                {
                    days = HANDLING_STRESS_DAYS;
                    fee = HANDLING_STRESS_FEE;
                }
                if (_WorkSelection.Equals(Constants.TIME_MANAGEMENT))
                {
                    days = TIME_MANAGEMENT_DAYS;
                    fee = TIME_MANAGEMENT_FEE;
                }
                if (_WorkSelection.Equals(Constants.SUPERVISION_SKILLS))
                {
                    days = SUPERVISION_DAYS;
                    fee = SUPERVISION_FEE;
                }
                if (_WorkSelection.Equals(Constants.NEGOTIATION))
                {
                    days = NEGOTIATION_DAYS;
                    fee = NEGOTIATION_FEE;
                }
                if (_WorkSelection.Equals(Constants.HOW_TO_INTERVIEW))
                {
                    days = INTERVIEW_DAYS;
                    fee = INTERVIEW_FEE;
                }
            }
            else
            {
                CostConversion = Constants.WORKSHOP_SELECTION;
            }
            if (_LocationSelection != null)
            {
                if (_LocationSelection.Equals(Constants.AUSTIN))
                {
                    lodging = AUSTIN_LODGE;
                }
                if (_LocationSelection.Equals(Constants.CHICAGO))
                {
                    lodging = CHICAGO_LODGE;
                }
                if (_LocationSelection.Equals(Constants.DALLAS))
                {
                    lodging = DALLAS_LODGE;
                }
                if (_LocationSelection.Equals(Constants.ORLANDO))
                {
                    lodging = ORLANDO_LODGE;
                }
                if (_LocationSelection.Equals(Constants.PHOENIX))
                {
                    lodging = PHOENIX_LODGE;
                }
                if (_LocationSelection.Equals(Constants.RALEIGH))
                {
                    lodging = RALEIGH_LODGE;
                }
            }
            else
            {
                CostConversion = Constants.LOCATION_SELECTION;
            }
            if ((_WorkSelection != null) && (_LocationSelection != null))
            {
                CostConversion = "Cost of " + _WorkSelection + " in " + _LocationSelection + " $" + ((decimal)((lodging * days) + fee)).ToString("F2");
            }
        }

        public Calculate()
        {
            _WorkList = new List<string>();
            _WorkList.Add(Constants.HANDLING_STRESS);
            _WorkList.Add(Constants.TIME_MANAGEMENT);
            _WorkList.Add(Constants.SUPERVISION_SKILLS);
            _WorkList.Add(Constants.NEGOTIATION);
            _WorkList.Add(Constants.HOW_TO_INTERVIEW);

            _LocationList = new List<string>();
            _LocationList.Add(Constants.AUSTIN);
            _LocationList.Add(Constants.CHICAGO);
            _LocationList.Add(Constants.DALLAS);
            _LocationList.Add(Constants.ORLANDO);
            _LocationList.Add(Constants.PHOENIX);
            _LocationList.Add(Constants.RALEIGH);
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void Notify(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        }
}
}
