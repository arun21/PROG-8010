﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Constants
    {
        public static int package_cost = 99;

        public static decimal percent_20 = 0.2m;

        public static decimal percent_30 = 0.3m;

        public static decimal percent_40 = 0.4m;

        public static decimal percent_50 = 0.5m;

        public static string discount_20 = "20% Discount";

        public static string discount_30 = "30% Discount";

        public static string discount_40 = "40% Discount";

        public static string discount_50 = "50% Discount";

        public static string no_discount = "No Discount";

        public static string amount_info_message = "Please insert proper number of packages";
    }
}
