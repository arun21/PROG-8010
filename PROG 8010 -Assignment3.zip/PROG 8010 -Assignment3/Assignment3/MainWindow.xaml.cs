﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Assignment3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        decimal cal_amount = 0;
        decimal total_amt = 0;
        int nopkg = 0;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnClc_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                nopkg = int.Parse(txtQuantity.Text);
                if (nopkg > 0)
                {
                    int amount = Constants.package_cost * nopkg;
                    if (nopkg >= 10 && nopkg < 19)
                    {
                        lbldiscount.Content = Constants.discount_20;
                        cal_amount = Calculate.calculate_discount(amount, Constants.percent_20);

                    }
                    else if (nopkg >= 20 && nopkg < 49)
                    {
                        lbldiscount.Content = Constants.discount_30;
                        cal_amount = Calculate.calculate_discount(amount, Constants.percent_30);
                    }
                    else if (nopkg >= 50 && nopkg < 99)
                    {
                        lbldiscount.Content = Constants.discount_40;
                        cal_amount = Calculate.calculate_discount(amount, Constants.percent_40);
                    }
                    else if (nopkg >= 100)
                    {
                        lbldiscount.Content = Constants.discount_50;
                        cal_amount = Calculate.calculate_discount(amount, Constants.percent_50);
                    }
                    else
                    {
                        lbldiscount.Content = Constants.no_discount;
                        cal_amount = 0;
                    }
                    total_amt = Calculate.calculate_total(amount, cal_amount);
                    lblAmt_discount.Content = cal_amount.ToString();
                    lblTot_Amount.Content = total_amt.ToString();
                }
                else
                {
                    MessageBox.Show(Constants.amount_info_message);
                    txtQuantity.Text = "0";
                }
            }catch(Exception ex)
            {
                MessageBox.Show(Constants.amount_info_message);
                txtQuantity.Text = "0";
            }
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            lbldiscount.Content = Constants.no_discount;
            txtQuantity.Text = "0";
            lblAmt_discount.Content = "0";
            lblTot_Amount.Content = "0";
        }

        private void txtQuantity_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox tb = (TextBox)sender;
            tb.Text = "";
        }
    }
}
