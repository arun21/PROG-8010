﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Calculate
    {
        public static Decimal calculate_discount(int amt, decimal discount)
        {
            Decimal discount_amt = (decimal) amt * discount;
            
            return discount_amt;
        }

        public static decimal calculate_total(int amount, decimal discount)
        {
            return (decimal)amount - discount;
        }
    }
}
